package com.example.getloginpassappbatsaev;

import android.app.Activity;

public class ViewActivity extends Activity {
}
